Lapresa M, Zollo L and Cordella F (2022),
A user-friendly automatic toolbox for
hand kinematic analysis, clinical
assessment and postural
synergies extraction.
Front. Bioeng. Biotechnol. 10:1010073.
doi: 10.3389/fbioe.2022.1010073

***********************************************************************************************************

In this text file, some guidelines about how to write the script for computing and saving joint angles are provided:

- the script should take as input the marker trajectories (e.g., Mx, My and Mz coordinates)
- from these 3D marker trajectories, it could be useful to create a matrix containing 3 columns (i.e., the 3 coordinates of the markers)
- after implementing your own kinematic protocol to reconstruct joint angles, the script should save in the stuct the angles and the marker positions
ATTENTION PLEASE: a flag (app.flag_calibration) with an "if" condition is used in the script to save data from the calibration trial or from the trial to be inspected
- the struct should be organized as in the following examples:
	struct_name.Calibration.angles.mcp2_FE (for the calibration trial)
	struct_name.Trial_number.angles.mcp2_FE (for the trial to be inspected)
	struct_name.Trial_number.marker_positions.mcp2 (for saving marker positions in the struct)
- the struct should be saved in the current folder with the command "save" in the code

************************************************************************************************************

IMPORTANT: please download the SynGrasp toolbox by M. Malvezzi, G. Gioioso, G. Salvietti, D.Prattichizzo from 
http://sirslab.dii.unisi.it/syngrasp/
to be able to visualize the custom virtual hand. In particular, the tool by Martina Lapresa et al. requires 
to take as input the path of the SGinstall.m file. If the user is not interested in visualizing 
the hand posture through the virtual hand, please comment all the parts of the code that refer to the use of SynGrasp.

