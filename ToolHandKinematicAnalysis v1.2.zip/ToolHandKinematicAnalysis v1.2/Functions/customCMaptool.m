% Copyright 2022 Martina Lapresa, Loredana Zollo, Francesca Cordella
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.

% Script to generate a CustomColorMap around a value.
function customCMap = customCMaptool(data,middlevalue,bottomcolor, indexColor, topColor)

L = length(data);
index = middlevalue;


% Create color map ranging from bottom color to index color
% Multipling number of points by 100 adds more resolution
customCMap1 = [linspace(bottomcolor(1),indexColor(1),index)',...
            linspace(bottomcolor(2),indexColor(2),index)',...
            linspace(bottomcolor(3),indexColor(3),index)'];
% Create color map ranging from index color to top color
% Multipling number of points by 100 adds more resolution
customCMap2 = [linspace(indexColor(1),topColor(1),(L-index))',...
            linspace(indexColor(2),topColor(2),(L-index))',...
            linspace(indexColor(3),topColor(3),(L-index))'];
customCMap = [customCMap1;customCMap2];  % Combine colormaps
colormap(customCMap)
%save('customCMap', 'customCMap')
% psudo = pcolor(data);
% colorbar